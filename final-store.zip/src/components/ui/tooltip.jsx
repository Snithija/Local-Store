export const TooltipProvider = ({ children }) => children;
